const BooksData = [
    { 
    id: '1',
    genre:"History",
    category:"books", 
    name: 'book 1', 
    thumbnail: "https://raw.githubusercontent.com/akhzarna/AllPDF/main/Deeniat.jpg",
    image: require('../assets/books.jpg'),
    description:"n  n the enchanting world of 'Mystic Realms,' embark on a thrilling adventure that transcends time and space. 'Echoes of Eternity,' the first installment in this epic fantasy series, sweeps readers into a realm where magic and destiny collide. Follow the journey of Elara, a spirited young mage with an unquenchable curiosity for the hidden secrets of the universe. As ancient prophecies begin to unfold and shadows of darkness threaten to engulf the land, Elara finds herself at the heart of a quest that could reshape the very fabric of reality. With vivid landscapes, captivating characters, and a spellbinding narrative, 'Echoes of Eternity' beckons readers to discover the magic within and beyondn the enchanting world of 'Mystic Realms,' embark on a thrilling adventure that transcends time and space. 'Echoes of Eternity,' the first installment in this epic fantasy series, sweeps readers into a realm where magic and destiny collide. Follow the journey of Elara, a spirited young mage with an unquenchable curiosity for the hidden secrets of the universe. As ancient prophecies begin to unfold and shadows of darkness threaten to engulf the land, Elara finds herself at the heart of a quest that could reshape the very fabric of reality. With vivid landscapes, captivating characters, and a spellbinding narrative, 'Echoes of Eternity' beckons readers to discover the magic within and beyond the enchanting world of 'Mystic Realms,' embark on a thrilling adventure that transcends time and space. 'Echoes of Eternity,' the first installment in this epic fantasy series, sweeps readers into a realm where magic and destiny collide. Follow the journey of Elara, a spirited young mage with an unquenchable curiosity for the hidden secrets of the universe. As ancient prophecies begin to unfold and shadows of darkness threaten to engulf the land, Elara finds herself at the heart of a quest that could reshape the very fabric of reality. With vivid landscapes, captivating characters, and a spellbinding narrative, 'Echoes of Eternity' beckons readers to discover the magic within and beyond",
    author: "assasad khan" 
  },

    { 
      id: '2',
      genre:"Comedy",
      category:"books", 
      type:"books", 
      name: 'book 2', 
      image: require('../assets/books.jpg'),
      description:"sadasdsadasasdasd",
      thumbnail: "https://raw.githubusercontent.com/akhzarna/AllPDF/main/Tehreek-E-Islami-Ka-Ainda-Lahe-Amal.jpg"
    },
    { 
      id: '3',
      genre:"Fiction", 
      category:"books", 
      name: 'book 3', 
      image: require('../assets/books.jpg'),
      thumbnail: "https://raw.githubusercontent.com/akhzarna/AllPDF/main/Quran-ki-4-Buniyadi-Istalahein-Islamic-Book-Bazar_1.jpg",
      description:"n the enchanting world of 'Mystic Realms,' embark on a thrilling adventure that transcends time and space. 'Echoes of Eternity,' the first installment in this epic fantasy series, sweeps readers into a realm where magic and destiny collide. Follow the journey of Elara, a spirited young mage with an unquenchable curiosity for the hidden secrets of the universe. As ancient prophecies begin to unfold and shadows of darkness threaten to engulf the land, Elara finds herself at the heart of a quest that could reshape the very fabric of reality. With vivid landscapes, captivating characters, and a spellbinding narrative, 'Echoes of Eternity' beckons readers to discover the magic within and beyond",author: "assasad khan" },
    { 
      id: '4',
      genre:"Espionage",
      category:"books",  
      name: 'book 1', 
      image: require('../assets/books.jpg'),
      description:"sadasdsadasasdasd" ,
      author: "assasad khan",
      thumbnail: "https://raw.githubusercontent.com/akhzarna/AllPDF/main/Quran-ki-4-Buniyadi-Istalahein-Islamic-Book-Bazar_1.jpg"
    },
    { 
      id: '5',
      genre:"World War", 
      category:"books", 
      name: 'book 2', 
      thumbnail: "https://raw.githubusercontent.com/akhzarna/AllPDF/main/Deeniat.jpg",
      image: require('../assets/books.jpg'),
      description:"n the enchanting world of 'Mystic Realms,' embark on a thrilling adventure that transcends time and space. 'Echoes of Eternity,' the first installment in this epic fantasy series, sweeps readers into a realm where magic and destiny collide. Follow the journey of Elara, a spirited young mage with an unquenchable curiosity for the hidden secrets of the universe. As ancient prophecies begin to unfold and shadows of darkness threaten to engulf the land, Elara finds herself at the heart of a quest that could reshape the very fabric of reality. With vivid landscapes, captivating characters, and a spellbinding narrative, 'Echoes of Eternity' beckons readers to discover the magic within and beyond",
      author: "assasad khan"},
    
    
    { 
    id: '6', 
    genre:"History", 
    category:"books",
    name: 'book 3', 
    thumbnail: "https://raw.githubusercontent.com/akhzarna/AllPDF/main/Deeniat.jpg",
    image: require('../assets/books.jpg'),
    description:"n the enchanting world of 'Mystic Realms,' embark on a thrilling adventure that transcends time and space. 'Echoes of Eternity,' the first installment in this epic fantasy series, sweeps readers into a realm where magic and destiny collide. Follow the journey of Elara, a spirited young mage with an unquenchable curiosity for the hidden secrets of the universe. As ancient prophecies begin to unfold and shadows of darkness threaten to engulf the land, Elara finds herself at the heart of a quest that could reshape the very fabric of reality. With vivid landscapes, captivating characters, and a spellbinding narrative, 'Echoes of Eternity' beckons readers to discover the magic within and beyond",author: "assasad khan" 
  },
    // Add more authors with images as needed
  ];
  
export default BooksData